import { isKeyRelease, Key, matchesKey, truncateToWidth, visibleWidth } from "@earendil-works/pi-tui";
import { snapshotExternalRuns } from "../api/external-runs.js";
import { formatModelThinking } from "../shared/formatters.js";
import { projectAsyncWorkflowRows } from "../runs/shared/async-status-projection.js";
import { contextModeLabel } from "../runs/shared/context-mode.js";
import { formatWorkflowJsonPreview } from "../workflows/scripted-workflow.js";
import { hostStepReportName, hostStepVerdictLabel } from "../runs/shared/host-step-status.js";
import { isStaleExtensionContextError } from "../shared/extension-context.js";
import { inlineWorkflowRenderKey } from "./render.js";
import { runningTone } from "./running-tone.js";
import { childThinkingLevel } from "../shared/model-info.js";
import { formatWorkflowChecklistBottleneck, formatWorkflowChecklistPhase, formatWorkflowChecklistSummary, projectWorkflowChecklist } from "../workflows/workflow-checklist.js";
export const FLEET_STATUS_WIDGET_KEY = "subagent-fleet-status";
// Six rows fit the accepted collapsed hierarchy: one owner, four visible descendants, and overflow.
const MAX_AGENT_ROWS = 6;
const REFRESH_MS = 500;
const FLEET_AGENT_IDENTITY_COLORS = [
    "mdLink",
    "mdHeading",
    "syntaxFunction",
    "syntaxKeyword",
    "syntaxNumber",
    "syntaxType",
    "syntaxVariable",
    "customMessageLabel",
    "toolTitle",
    "thinkingMedium",
    "thinkingHigh",
    "mdQuote",
    "bashMode",
    "userMessageText",
    "mdCode",
    "syntaxOperator",
];
export function fleetAgentIdentityColor(identity) {
    let hash = 2166136261;
    for (let i = 0; i < identity.length; i++) {
        hash ^= identity.charCodeAt(i);
        hash = Math.imul(hash, 16777619);
    }
    return FLEET_AGENT_IDENTITY_COLORS[(hash >>> 0) % FLEET_AGENT_IDENTITY_COLORS.length];
}
export function resolveFleetViewPlacement(value) {
    return value === "aboveEditor" ? "aboveEditor" : "belowEditor";
}
export function formatFleetElapsed(ms) {
    return `${Math.max(0, Math.round(ms / 1000))}s`;
}
function detailElapsed(row) {
    const duration = row.state === "running" && row.startedAt !== undefined
        ? Date.now() - row.startedAt
        : row.durationMs ?? (row.startedAt !== undefined && row.endedAt !== undefined ? row.endedAt - row.startedAt : undefined);
    return duration !== undefined ? formatFleetElapsed(duration) : undefined;
}
export function formatFleetTokens(count, window, windowCount = 1) {
    const compact = (value) => value >= 1_000_000
        ? `${(value / 1_000_000).toFixed(1)}M`
        : value >= 1_000
            ? `${(value / 1_000).toFixed(1)}k`
            : `${Math.max(0, Math.round(value))}`;
    return window !== undefined
        ? `↓ ${compact(window)} ${windowCount > 1 ? "Σ windows" : "window"} · ${compact(count)} spent`
        : `↓ ${compact(count)} tokens`;
}
function rightAlign(left, right, width) {
    const rightWidth = visibleWidth(right);
    const maxLeftWidth = Math.max(0, width - rightWidth - 1);
    const leftClamped = truncateToWidth(left, maxLeftWidth);
    const gap = Math.max(1, width - visibleWidth(leftClamped) - rightWidth);
    return truncateToWidth(`${leftClamped}${" ".repeat(gap)}${right}`, width);
}
function isActiveState(value) {
    return value === "running" || value === "queued" || value === "pending";
}
function nestedRunLabel(run) {
    if (run.agent)
        return run.agent;
    if (run.agents?.length)
        return run.agents.length === 1 ? run.agents[0] : `${run.agents.slice(0, 2).join(", ")}${run.agents.length > 2 ? ` +${run.agents.length - 2}` : ""}`;
    return run.id;
}
function nestedActivity(node) {
    if (node.currentTool)
        return `tool ${node.currentTool}`;
    if (node.currentPath)
        return node.currentPath.split(/[\\/]/).at(-1);
    if (node.activityState === "needs_attention")
        return "needs attention";
    if (node.activityState === "active_long_running")
        return "long-running";
    return undefined;
}
function visibleWorkflowRows(rows, visibleLimit) {
    if (!rows?.length)
        return [];
    if (rows.length <= visibleLimit)
        return rows;
    const selected = new Set();
    for (const [index, row] of rows.entries()) {
        if (!isWorkflowRowTerminal(row))
            selected.add(index);
        if (selected.size >= visibleLimit)
            break;
    }
    for (let index = rows.length - 1; index >= 0 && selected.size < visibleLimit; index--)
        selected.add(index);
    const visible = [...selected].sort((left, right) => left - right).map((index) => rows[index]);
    return [{ name: `… +${rows.length - visible.length} hidden workflow steps`, state: "complete", overflow: rows.length - visible.length }, ...visible];
}
function visibleWorkflowPhases(checklist, visibleLimit) {
    const phases = checklist?.phases ?? [];
    if (phases.length <= visibleLimit)
        return phases;
    const selected = new Set();
    for (const [index, phase] of phases.entries()) {
        if (phase.state !== "complete")
            selected.add(index);
        if (selected.size >= visibleLimit)
            break;
    }
    for (let index = phases.length - 1; index >= 0 && selected.size < visibleLimit; index--)
        selected.add(index);
    return [...selected].sort((left, right) => left - right).map((index) => phases[index]);
}
function isWorkflowRowTerminal(row) {
    if (row.kind)
        return row.state === "done" || row.state === "cancelled" || row.state === "error";
    return row.state === "complete" || row.state === "completed";
}
function nestedStatusGlyph(state, theme, thinking) {
    if (state === "running")
        return runningTone(theme, thinking)("●");
    if (state === "queued" || state === "pending" || state === "planned")
        return theme.fg("muted", "◦");
    if (state === "complete" || state === "completed")
        return theme.fg("success", "✓");
    if (state === "failed" || state === "rejected")
        return theme.fg("error", "✗");
    return theme.fg("warning", "■");
}
function nestedStepDisplayCount(steps, start = 0) {
    let count = 0;
    for (let index = start; index < (steps?.length ?? 0); index++) {
        count += 1 + nestedDisplayCount(steps[index].children);
    }
    return count;
}
function nestedDisplayCount(children, start = 0) {
    let count = 0;
    for (let index = start; index < (children?.length ?? 0); index++) {
        const child = children[index];
        const steps = (child.mode === "parallel" || child.mode === "chain") ? child.steps ?? [] : [];
        count += steps.length > 0 ? nestedStepDisplayCount(steps) : 1;
        count += nestedDisplayCount(child.children);
    }
    return count;
}
function nestedFleetRows(children, visibleLimit) {
    const rows = [];
    let omitted = 0;
    const appendRuns = (runs, depth) => {
        for (let runIndex = 0; runIndex < (runs?.length ?? 0); runIndex++) {
            const child = runs[runIndex];
            const steps = (child.mode === "parallel" || child.mode === "chain") ? child.steps ?? [] : [];
            if (steps.length > 0) {
                for (let stepIndex = 0; stepIndex < steps.length; stepIndex++) {
                    if (rows.length >= visibleLimit) {
                        omitted += nestedStepDisplayCount(steps, stepIndex);
                        omitted += nestedDisplayCount(child.children);
                        omitted += nestedDisplayCount(runs, runIndex + 1);
                        return false;
                    }
                    const step = steps[stepIndex];
                    const modelThinking = formatModelThinking(step.model, step.thinking) || undefined;
                    const thinking = childThinkingLevel(step);
                    const activity = nestedActivity(step);
                    rows.push({
                        name: step.agent,
                        agentIdentity: step.agent,
                        state: step.status,
                        depth,
                        ...(modelThinking ? { modelThinking } : {}),
                        ...(thinking ? { thinking } : {}),
                        ...(activity ? { activity } : {}),
                        ...(step.startedAt !== undefined ? { startedAt: step.startedAt } : {}),
                        ...(step.endedAt !== undefined ? { endedAt: step.endedAt } : {}),
                    });
                    if (!appendRuns(step.children, depth + 1)) {
                        omitted += nestedStepDisplayCount(steps, stepIndex + 1);
                        omitted += nestedDisplayCount(child.children);
                        omitted += nestedDisplayCount(runs, runIndex + 1);
                        return false;
                    }
                }
            }
            else {
                if (rows.length >= visibleLimit) {
                    omitted += nestedDisplayCount(runs, runIndex);
                    return false;
                }
                const modelThinking = formatModelThinking(child.model, child.thinking) || undefined;
                const thinking = childThinkingLevel(child);
                const activity = nestedActivity(child);
                rows.push({
                    name: nestedRunLabel(child),
                    agentIdentity: child.agent ?? child.agents?.join("\0") ?? child.id,
                    state: child.state,
                    depth,
                    ...(modelThinking ? { modelThinking } : {}),
                    ...(thinking ? { thinking } : {}),
                    ...(activity ? { activity } : {}),
                    ...(child.startedAt !== undefined ? { startedAt: child.startedAt } : {}),
                    ...(child.endedAt !== undefined ? { endedAt: child.endedAt } : {}),
                });
            }
            if (!appendRuns(child.children, depth + 1)) {
                omitted += nestedDisplayCount(runs, runIndex + 1);
                return false;
            }
        }
        return true;
    };
    appendRuns(children, 0);
    if (omitted > 0)
        rows.push({ name: `… +${omitted} more nested leaves`, state: "complete", depth: 0, overflow: omitted });
    return rows;
}
function fleetTreeRows(entries) {
    const rows = [];
    const entryKeys = new Set(entries.map((entry) => entry.key));
    const childrenByParent = new Map();
    for (const entry of entries) {
        if (!entry.parentKey || !entryKeys.has(entry.parentKey))
            continue;
        const children = childrenByParent.get(entry.parentKey) ?? [];
        children.push(entry);
        childrenByParent.set(entry.parentKey, children);
    }
    for (const entry of entries) {
        if (entry.parentKey && entryKeys.has(entry.parentKey))
            continue;
        rows.push({ kind: "owner", entry });
        const attached = childrenByParent.get(entry.key) ?? [];
        const workflowPhases = visibleWorkflowPhases(entry.workflowChecklist, attached.length > 0 ? 2 : 4);
        const workflowRows = visibleWorkflowRows(entry.workflowRows, attached.length > 0 ? 2 : 4);
        for (const [index, child] of attached.entries()) {
            const nested = nestedFleetRows(child.nestedChildren, 3);
            const laterRows = index < attached.length - 1 || workflowPhases.length > 0 || workflowRows.length > 0 || Boolean(entry.nestedChildren?.length);
            rows.push({ kind: "child", entry: child, last: !laterRows && nested.length === 0 });
            for (const [nestedIndex, row] of nested.entries())
                rows.push({
                    kind: "nested",
                    ownerKey: child.key,
                    row: { ...row, depth: row.depth + 1 },
                    last: nestedIndex === nested.length - 1 && !laterRows,
                });
        }
        for (const [index, phase] of workflowPhases.entries())
            rows.push({
                kind: "workflow-phase",
                ownerKey: entry.key,
                phase,
                last: index === workflowPhases.length - 1 && workflowRows.length === 0 && !entry.nestedChildren?.length,
            });
        for (const [index, row] of workflowRows.entries())
            rows.push({ kind: "workflow", ownerKey: entry.key, row, last: index === workflowRows.length - 1 && !entry.nestedChildren?.length });
        const nested = nestedFleetRows(entry.nestedChildren, attached.length > 0 ? 3 : 4);
        for (const [index, row] of nested.entries())
            rows.push({ kind: "nested", ownerKey: entry.key, row, last: index === nested.length - 1 });
    }
    return rows;
}
function foregroundDescription(control, description) {
    if (!control.parentWorkflowRunId)
        return description;
    const workflow = `workflow child: ${control.parentWorkflowRunId}${control.workflowKey ? ` (${control.workflowKey})` : ""}`;
    return description ? `${workflow} · ${description}` : workflow;
}
function workflowIdentityCandidates(step) {
    return [...new Set([step.workflowKey, step.runId].filter((value) => typeof value === "string" && value.length > 0))];
}
function asyncJobIdentityCandidates(job) {
    return [...new Set([job.workflowKey, job.asyncId].filter((value) => typeof value === "string" && value.length > 0))];
}
function linkedWorkflowParentKey(parentWorkflowRunId, activeWorkflowKeys) {
    if (!parentWorkflowRunId)
        return undefined;
    const parentKey = `async:${parentWorkflowRunId}`;
    return activeWorkflowKeys.has(parentKey) ? parentKey : undefined;
}
function workflowStepsWithoutMaterializedChildren(steps, materializedChildIds) {
    if (!steps?.length || !materializedChildIds?.size)
        return steps;
    return steps.filter((step) => !workflowIdentityCandidates(step).some((identity) => materializedChildIds.has(identity)));
}
function activeLeafAgentCount(entries) {
    return entries.filter((entry) => !entry.workflowWrapper && !entry.surface).length;
}
function projectPaneNeedsAttention(pane) {
    return ["attention", "blocked", "paused", "failed", "error"].some((status) => pane.agentStatus.includes(status))
        || pane.summary?.includes("⚠") === true;
}
function projectName(projectRoot) {
    return projectRoot.split(/[\\/]/).filter(Boolean).at(-1) ?? projectRoot;
}
function projectPaneEntries(state) {
    return [...(state.herdrProjectPanes?.values() ?? [])]
        .filter((pane) => pane.state === "open")
        .sort((left, right) => left.openedAt.localeCompare(right.openedAt) || left.projectRoot.localeCompare(right.projectRoot))
        .map((pane) => ({
        key: `project-pane:${pane.projectRoot}`,
        surface: "project-pane",
        agent: `${projectName(pane.projectRoot)} · ${pane.paneId}`,
        description: pane.summary,
        startedAt: Date.parse(pane.openedAt) || pane.refreshedAt,
        tokens: 0,
        state: pane.agentStatus || "unknown",
        projectPane: pane,
    }));
}
export function collectFleetStatusEntries(state) {
    const now = Date.now();
    const entries = [];
    const activeWorkflowKeys = new Set([...state.asyncJobs.values()]
        .filter((job) => job.mode === "workflow" && isActiveState(job.status))
        .map((job) => `async:${job.asyncId}`));
    const materializedChildrenByWorkflow = new Map();
    for (const job of state.asyncJobs.values()) {
        if (!isActiveState(job.status) || !job.parentWorkflowRunId)
            continue;
        const parentKey = linkedWorkflowParentKey(job.parentWorkflowRunId, activeWorkflowKeys);
        if (!parentKey)
            continue;
        const childIds = materializedChildrenByWorkflow.get(parentKey) ?? new Set();
        for (const identity of asyncJobIdentityCandidates(job))
            childIds.add(identity);
        materializedChildrenByWorkflow.set(parentKey, childIds);
    }
    for (const control of state.foregroundControls.values()) {
        const linkedParentKey = linkedWorkflowParentKey(control.parentWorkflowRunId, activeWorkflowKeys);
        if (control.activeChildren) {
            const nestedChildren = control.nestedChildren ?? [];
            const nestedChildrenByParentStep = new Map();
            for (const nested of nestedChildren) {
                if (nested.parentStepIndex === undefined)
                    continue;
                const children = nestedChildrenByParentStep.get(nested.parentStepIndex) ?? [];
                children.push(nested);
                nestedChildrenByParentStep.set(nested.parentStepIndex, children);
            }
            for (const child of [...control.activeChildren.values()].sort((left, right) => left.index - right.index)) {
                const modelThinking = formatModelThinking(child.model, child.thinking) || undefined;
                const childNestedChildren = nestedChildrenByParentStep.get(child.index)
                    ?? (control.activeChildren.size === 1 && nestedChildren.length ? nestedChildren : undefined);
                entries.push({
                    key: `foreground-active:${control.runId}:${child.index}`,
                    ...(linkedParentKey ? { parentKey: linkedParentKey } : {}),
                    agent: child.agent,
                    ...(modelThinking ? { modelThinking } : {}),
                    description: foregroundDescription(control, child.description),
                    startedAt: child.startedAt,
                    tokens: child.tokens ?? 0,
                    ...(child.window !== undefined ? { window: child.window } : {}),
                    state: "running",
                    ...(childNestedChildren?.length ? { nestedChildren: childNestedChildren } : {}),
                });
            }
            continue;
        }
        const modelThinking = formatModelThinking(control.model, control.thinking) || undefined;
        entries.push({
            key: `foreground-active:${control.runId}:${control.currentIndex ?? 0}`,
            ...(linkedParentKey ? { parentKey: linkedParentKey } : {}),
            agent: control.currentAgent ?? control.mode,
            ...(modelThinking ? { modelThinking } : {}),
            description: foregroundDescription(control, control.description),
            startedAt: control.startedAt,
            tokens: control.tokens ?? 0,
            ...(control.window !== undefined ? { window: control.window } : {}),
            state: "running",
            ...(control.nestedChildren?.length ? { nestedChildren: control.nestedChildren } : {}),
        });
    }
    for (const job of state.asyncJobs.values()) {
        if (!isActiveState(job.status))
            continue;
        const startedAt = job.startedAt ?? job.updatedAt ?? now;
        const linkedParentKey = linkedWorkflowParentKey(job.parentWorkflowRunId, activeWorkflowKeys);
        if (job.mode === "workflow") {
            const latestEmit = job.workflow?.emits?.length ? formatWorkflowJsonPreview(job.workflow.emits.at(-1), 120) : undefined;
            const workflowSteps = workflowStepsWithoutMaterializedChildren(job.steps, materializedChildrenByWorkflow.get(`async:${job.asyncId}`));
            const workflowRows = projectAsyncWorkflowRows(workflowSteps, job.workflowGraph ?? job.hostSteps, job.preflight);
            const workflowChecklist = projectWorkflowChecklist({
                graph: job.workflowGraph,
                steps: job.steps,
                hostSteps: job.hostSteps,
                preflight: job.preflight,
                trace: job.workflow?.trace,
                now,
            });
            entries.push({
                key: `async:${job.asyncId}`,
                ...(linkedParentKey ? { parentKey: linkedParentKey } : {}),
                workflowWrapper: true,
                agent: "workflow",
                description: latestEmit !== undefined ? `latest emit: ${latestEmit}` : job.description,
                startedAt,
                tokens: job.totalTokens?.total ?? 0,
                ...(job.totalTokens?.window !== undefined ? { window: job.totalTokens.window } : {}),
                state: job.status,
                ...(workflowRows.length ? { workflowRows } : {}),
                ...(workflowChecklist.total ? { workflowChecklist } : {}),
                ...(job.nestedChildren?.length ? { nestedChildren: job.nestedChildren } : {}),
            });
            continue;
        }
        const steps = job.steps?.length
            ? job.steps
            : job.agents?.map((agent, index) => {
                const pending = job.status === "queued"
                    || (job.mode === "chain" && !job.activeParallelGroup && index !== (job.currentStep ?? 0));
                return { agent, index, status: pending ? "pending" : "running" };
            });
        if (!steps?.length) {
            entries.push({
                key: `async:${job.asyncId}`,
                ...(linkedParentKey ? { parentKey: linkedParentKey } : {}),
                agent: job.mode ?? "subagent",
                description: job.description,
                startedAt,
                tokens: job.totalTokens?.total ?? 0,
                ...(job.totalTokens?.window !== undefined ? { window: job.totalTokens.window } : {}),
                state: job.status,
                ...(job.nestedChildren?.length ? { nestedChildren: job.nestedChildren } : {}),
            });
            continue;
        }
        for (const [offset, step] of steps.entries()) {
            if (!isActiveState(step.status))
                continue;
            const index = step.index ?? offset;
            if (step.status === "pending" && job.mode === "chain" && !job.activeParallelGroup && index !== (job.currentStep ?? 0))
                continue;
            const modelThinking = formatModelThinking(step.model, step.thinking) || undefined;
            entries.push({
                key: `async:${job.asyncId}:${index}`,
                ...(linkedParentKey ? { parentKey: linkedParentKey } : {}),
                agent: step.agent,
                ...(step.label ? { displayLabel: `${step.label} (${step.agent})` } : {}),
                ...(modelThinking ? { modelThinking } : {}),
                description: step.description ?? job.description,
                startedAt: step.startedAt ?? startedAt,
                tokens: step.tokens?.total ?? (steps.length === 1 ? job.totalTokens?.total ?? 0 : 0),
                ...((step.tokens?.window ?? (steps.length === 1 ? job.totalTokens?.window : undefined)) !== undefined
                    ? { window: step.tokens?.window ?? job.totalTokens?.window }
                    : {}),
                state: step.status,
                ...((step.children?.length ?? 0) > 0
                    ? { nestedChildren: step.children }
                    : job.nestedChildren?.filter((nested) => nested.parentStepIndex === index).length
                        ? { nestedChildren: job.nestedChildren.filter((nested) => nested.parentStepIndex === index) }
                        : {}),
            });
        }
    }
    if (state.currentSessionId) {
        try {
            for (const run of snapshotExternalRuns(state.currentSessionId, { ignoreMalformed: true, onMalformedRecord: (message) => console.warn(`[pi-subagents] Removed ${message}`) })) {
                if (!isActiveState(run.state))
                    continue;
                entries.push({
                    key: `external:${run.id}`,
                    agent: `external · ${run.label}`,
                    description: run.currentAction ?? `source: ${run.source}`,
                    startedAt: run.startedAt,
                    tokens: 0,
                    state: run.state,
                    external: true,
                });
            }
        }
        catch (cause) {
            console.warn(`[pi-subagents] Failed to inspect external jobs: ${cause instanceof Error ? cause.message : String(cause)}`);
        }
    }
    entries.push(...projectPaneEntries(state));
    return entries.sort((left, right) => left.startedAt - right.startedAt || left.key.localeCompare(right.key));
}
export class SubagentFleetStatus {
    ctx;
    ui;
    tui;
    inputUnsubscribe;
    timer;
    widgetRegistered = false;
    active = false;
    selectedKey = "main";
    inspectorOpen = false;
    lastRenderKey = "";
    lastPaint;
    prepaint;
    entries = [];
    workflowSnapshots = new Map();
    onWorkflowCoverageChange;
    state;
    openInspector;
    refreshMs;
    maxAgentRows;
    placement;
    constructor(state, openInspector, options = {}) {
        this.state = state;
        this.openInspector = openInspector;
        this.refreshMs = options.refreshMs ?? REFRESH_MS;
        this.maxAgentRows = options.maxAgentRows ?? MAX_AGENT_ROWS;
        this.placement = options.placement ?? "belowEditor";
        this.onWorkflowCoverageChange = options.onWorkflowCoverageChange;
    }
    setContext(ctx) {
        if (!ctx.hasUI) {
            this.clearUiRegistration();
            return;
        }
        const ui = ctx.ui;
        if (this.ui === ui) {
            this.ctx = ctx;
            this.refresh();
            return;
        }
        this.clearUiRegistration();
        this.ctx = ctx;
        this.ui = ui;
        if (typeof ui.onTerminalInput === "function") {
            this.inputUnsubscribe = ui.onTerminalInput((data) => this.handleKey(data));
        }
        this.timer = setInterval(() => this.refresh(), this.refreshMs);
        this.timer.unref?.();
        this.refresh();
    }
    dispose() {
        this.clearUiRegistration();
        this.ctx = undefined;
        this.ui = undefined;
        this.entries = [];
        this.active = false;
        this.selectedKey = "main";
        this.inspectorOpen = false;
        this.lastRenderKey = "";
    }
    refresh() {
        this.prepaint = undefined;
        const ctx = this.getActiveUiContext();
        if (!ctx)
            return;
        if (this.state.widgetsSuspended) {
            this.clearWidget();
            return;
        }
        this.entries = collectFleetStatusEntries(this.state);
        this.workflowSnapshots.clear();
        if (this.active && !this.inspectorOpen && !this.state.fleetInspectorOpen && this.onWorkflowCoverageChange) {
            const childrenByParent = new Map();
            for (const child of this.state.asyncJobs.values()) {
                if (!child.parentWorkflowRunId)
                    continue;
                const children = childrenByParent.get(child.parentWorkflowRunId) ?? [];
                children.push(child);
                childrenByParent.set(child.parentWorkflowRunId, children);
            }
            const attachedByParent = new Map();
            for (const entry of this.entries) {
                if (!entry.parentKey)
                    continue;
                const attached = attachedByParent.get(entry.parentKey) ?? [];
                attached.push(entry);
                attachedByParent.set(entry.parentKey, attached);
            }
            for (const job of this.state.asyncJobs.values()) {
                // Fleet does not expand attached workflow wrappers or step descendants.
                // Unknown/unsupported coverage deliberately retains the async tree.
                if (job.mode !== "workflow" || !isActiveState(job.status) || job.parentWorkflowRunId
                    || job.nestedChildren?.length || job.steps?.some((step) => step.children?.length))
                    continue;
                const key = `async:${job.asyncId}`;
                const children = childrenByParent.get(job.asyncId) ?? [];
                const attached = attachedByParent.get(key) ?? [];
                if (children.length && job.status !== "running")
                    continue;
                // Even without workflow rows, these children plus their owner cannot fit.
                if (attached.length >= this.maxAgentRows)
                    continue;
                const rowKeys = new Set();
                let unsupported = false;
                for (const child of children) {
                    if (!isActiveState(child.status) || (child.mode !== "single" && child.mode !== "parallel" && child.mode !== "chain")
                        || child.hostSteps?.length || child.workflowGraph
                        || childrenByParent.has(child.asyncId) || child.nestedChildren?.length
                        || child.steps?.some((step) => step.children?.length || step.runner || !isActiveState(step.status))) {
                        unsupported = true;
                        break;
                    }
                    const count = child.steps?.length || child.agents?.length || 0;
                    if (!count || (child.stepsTotal ?? 0) > count || (child.chainStepCount ?? 0) > count) {
                        unsupported = true;
                        break;
                    }
                    for (let index = 0; index < count; index++)
                        rowKeys.add(`async:${child.asyncId}:${child.steps?.[index]?.index ?? index}`);
                }
                if (unsupported || attached.length !== rowKeys.size || attached.some((entry) => !rowKeys.has(entry.key)))
                    continue;
                this.workflowSnapshots.set(key, { snapshot: inlineWorkflowRenderKey(job, children), childRows: rowKeys });
            }
        }
        this.clampSelection();
        if (this.inspectorOpen || this.state.fleetInspectorOpen) {
            this.lastRenderKey = "";
            this.clearWidget();
            return;
        }
        if (!this.hasInlineSurface()) {
            this.active = false;
            this.selectedKey = "main";
            this.lastRenderKey = "";
            this.clearWidget();
            return;
        }
        const renderKey = this.getRenderKey();
        if (!this.active)
            this.clearWorkflowCoverage();
        // The async widget paints above the roster, so recompute coverage (structure and row fit) now.
        // Clearing it instead would flash the full workflow tree on every live-stat tick.
        else if (renderKey !== this.lastRenderKey && this.lastPaint) {
            const { width, theme } = this.lastPaint;
            this.prepaint = { key: renderKey, width, theme, lines: this.render(width, theme) };
        }
        if (!this.widgetRegistered) {
            ctx.ui.setWidget(FLEET_STATUS_WIDGET_KEY, (tui, theme) => {
                this.tui = tui;
                return {
                    render: (width) => {
                        this.lastPaint = { width, theme };
                        const prepaint = this.prepaint;
                        this.prepaint = undefined;
                        if (prepaint && prepaint.key === this.lastRenderKey && prepaint.key === this.getRenderKey()
                            && prepaint.width === width && prepaint.theme === theme && !this.state.widgetsSuspended
                            && !this.inspectorOpen && !this.state.fleetInspectorOpen)
                            return prepaint.lines;
                        return this.render(width, theme);
                    },
                    invalidate: () => {
                        this.lastRenderKey = "";
                        this.prepaint = undefined;
                    },
                    dispose: () => {
                        if (this.tui !== tui)
                            return;
                        this.prepaint = undefined;
                        this.lastPaint = undefined;
                        this.clearWorkflowCoverage();
                        this.widgetRegistered = false;
                        this.tui = undefined;
                    },
                };
            }, { placement: this.placement });
            this.widgetRegistered = true;
            this.lastRenderKey = renderKey;
            return;
        }
        if (renderKey === this.lastRenderKey) {
            // Repaint anyway while anything is running so the wall-clock
            // spinner animates between state changes (500ms tick).
            if (this.entries.some((entry) => entry.state === "running"))
                this.tui?.requestRender();
            return;
        }
        this.lastRenderKey = renderKey;
        this.tui?.requestRender();
    }
    handleKey(data) {
        if (this.state.widgetsSuspended)
            return undefined;
        const ctx = this.getActiveUiContext();
        if (!ctx || this.entries.length === 0 || isKeyRelease(data))
            return undefined;
        if (this.inspectorOpen)
            return undefined;
        if (!this.editorHasFocus()) {
            if (this.active)
                this.deactivate();
            return undefined;
        }
        if (!this.active) {
            const activates = matchesKey(data, "down") || matchesKey(data, "left");
            if (!activates || ctx.ui.getEditorText() !== "")
                return undefined;
            this.active = true;
            this.selectedKey = "main";
            this.refresh();
            return { consume: true };
        }
        const roster = this.rosterKeys();
        const selectedIndex = Math.max(0, roster.indexOf(this.selectedKey));
        if (matchesKey(data, "down") || matchesKey(data, "j")) {
            this.selectedKey = roster[Math.min(roster.length - 1, selectedIndex + 1)] ?? "main";
            this.refresh();
            return { consume: true };
        }
        if (matchesKey(data, "up") || matchesKey(data, "k")) {
            if (selectedIndex === 0) {
                this.deactivate();
                return { consume: true };
            }
            this.selectedKey = roster[selectedIndex - 1] ?? "main";
            this.refresh();
            return { consume: true };
        }
        if (matchesKey(data, "escape")) {
            this.deactivate();
            return { consume: true };
        }
        if (matchesKey(data, Key.enter)) {
            if (this.selectedKey === "main") {
                this.deactivate();
                return { consume: true };
            }
            this.inspectorOpen = true;
            this.refresh();
            const selectedKey = this.selectedKey;
            void Promise.resolve()
                .then(() => this.openInspector(selectedKey))
                .catch((error) => ctx.ui.notify(error instanceof Error ? error.message : String(error), "error"))
                .finally(() => {
                this.inspectorOpen = false;
                this.refresh();
            });
            return { consume: true };
        }
        this.deactivate();
        return undefined;
    }
    render(width, theme) {
        if (!this.hasInlineSurface() || this.state.widgetsSuspended || this.inspectorOpen || this.state.fleetInspectorOpen) {
            this.clearWorkflowCoverage();
            return [];
        }
        if (!this.active) {
            this.clearWorkflowCoverage();
            const workEntries = this.entries.filter((entry) => !entry.surface);
            const projectEntries = this.entries.filter((entry) => entry.surface === "project-pane");
            // Workflow totals can overlap child usage and omit live lanes. Do not
            // present either wrapper totals or an active-only sum as workflow spend.
            const hasWorkflow = workEntries.some((entry) => entry.workflowWrapper);
            const nativeEntries = workEntries.filter((entry) => !entry.external && !entry.workflowWrapper && !entry.parentKey);
            const tokens = nativeEntries.reduce((total, entry) => total + entry.tokens, 0);
            const window = nativeEntries.length > 0 && nativeEntries.every((entry) => entry.window !== undefined)
                ? nativeEntries.reduce((total, entry) => total + entry.window, 0)
                : undefined;
            const capacity = this.state.activeAsyncCapacity;
            const hasNativeRows = nativeEntries.length > 0 || hasWorkflow;
            const showNativeSummary = hasNativeRows || Boolean(capacity?.used);
            const asyncRuns = capacity && showNativeSummary && (capacity.used > 0 || capacity.limit > 0) ? `Async runs ${capacity.used}/${capacity.limit || "∞"}` : "";
            const activeEntries = activeLeafAgentCount(workEntries);
            const noun = workEntries.some((entry) => entry.external) ? "job" : "agent";
            const agents = activeEntries > 0 ? `${activeEntries} active ${noun}${activeEntries === 1 ? "" : "s"}` : "";
            const paneAttention = projectEntries.filter((entry) => entry.projectPane && projectPaneNeedsAttention(entry.projectPane)).length;
            const panes = projectEntries.length > 0 ? `${projectEntries.length} pane${projectEntries.length === 1 ? "" : "s"}${paneAttention ? ` (${paneAttention} ⚠)` : ""}` : "";
            const label = [agents, asyncRuns, panes].filter(Boolean).join(" · ");
            const nativeUsage = formatFleetTokens(tokens, window, nativeEntries.length);
            const usage = hasWorkflow
                ? nativeEntries.length > 0 ? `standalone: ${nativeUsage} · workflow usage on child rows` : "usage on child rows"
                : nativeUsage;
            const detail = [showNativeSummary ? usage : undefined, "↓/← to inspect"].filter(Boolean).join(" · ");
            return [truncateToWidth(`  ${theme.fg("muted", label)}${label && detail ? " · " : ""}${theme.fg("dim", detail)}`, width)];
        }
        const roster = this.rosterKeys();
        const selectedIndex = Math.max(0, roster.indexOf(this.selectedKey));
        const rosterIndexByKey = new Map();
        for (const [index, entry] of this.entries.entries()) {
            if (!rosterIndexByKey.has(entry.key))
                rosterIndexByKey.set(entry.key, index + 1);
        }
        const lines = [truncateToWidth(`  ${theme.fg("dim", "↑↓/jk select · enter inspect · esc back")}`, width), ""];
        lines.push(truncateToWidth(`  ${this.bullet(0, selectedIndex, theme)} main`, width));
        const workEntries = this.entries.filter((entry) => !entry.surface);
        const tree = fleetTreeRows(workEntries);
        const selectedTreeIndex = Math.max(0, tree.findIndex((row) => (row.kind === "owner" || row.kind === "child") && row.entry.key === this.selectedKey));
        const visibleCount = Math.min(this.maxAgentRows, tree.length);
        const start = selectedTreeIndex < visibleCount ? 0 : selectedTreeIndex - visibleCount + 1;
        const hiddenBelow = tree.length - (start + visibleCount);
        if (start > 0)
            lines.push(rightAlign("", theme.fg("dim", `↑ ${start} more`), width));
        for (let index = start; index < start + visibleCount; index++) {
            const row = tree[index];
            if (row.kind === "owner" || row.kind === "child") {
                const rosterIndex = rosterIndexByKey.get(row.entry.key) ?? 0;
                lines.push(this.renderEntry(rosterIndex, selectedIndex, row.entry, width, theme, row.kind === "child" ? (row.last ? "└─" : "├─") : undefined));
            }
            else if (row.kind === "workflow") {
                lines.push(this.renderWorkflowRow(row.row, row.last, width, theme));
            }
            else if (row.kind === "workflow-phase") {
                lines.push(this.renderWorkflowPhaseRow(row.phase, row.last, width, theme));
            }
            else {
                lines.push(this.renderNestedRow(row.row, row.last, width, theme));
            }
        }
        if (hiddenBelow > 0)
            lines.push(rightAlign("", theme.fg("dim", `↓ ${hiddenBelow} more`), width));
        if (this.ui && this.widgetRegistered && this.onWorkflowCoverageChange) {
            const coverage = new Map();
            for (const [key, { snapshot, childRows }] of this.workflowSnapshots) {
                const ownerIndex = tree.findIndex((row) => row.kind === "owner" && row.entry.key === key);
                const owner = tree[ownerIndex];
                if (owner?.kind !== "owner" || ownerIndex < start)
                    continue;
                const count = childRows.size + (owner.entry.workflowRows?.length ?? 0) + (owner.entry.workflowChecklist?.phases.length ?? 0);
                if (!count || ownerIndex + count >= start + visibleCount)
                    continue;
                const descendants = tree.slice(ownerIndex + 1, ownerIndex + count + 1);
                if (!descendants.every((row) => (row.kind === "workflow" && row.ownerKey === key && !row.row.overflow
                    && visibleWidth(this.renderWorkflowRow(row.row, row.last, Infinity, theme)) <= width)
                    || (row.kind === "workflow-phase" && row.ownerKey === key
                        && visibleWidth(this.renderWorkflowPhaseRow(row.phase, row.last, Infinity, theme)) <= width)
                    || (row.kind === "child" && childRows.has(row.entry.key)
                        && visibleWidth(this.renderEntry(rosterIndexByKey.get(row.entry.key) ?? 0, selectedIndex, row.entry, 0, theme, row.last ? "└─" : "├─", true)) <= width)))
                    continue;
                if (childRows.size && visibleWidth(this.renderEntry(rosterIndexByKey.get(key) ?? 0, selectedIndex, owner.entry, 0, theme, undefined, true)) > width)
                    continue;
                coverage.set(key.slice("async:".length), snapshot);
            }
            this.onWorkflowCoverageChange(this.ui, coverage);
        }
        this.renderProjectPaneSection(lines, selectedIndex, width, theme, rosterIndexByKey);
        return lines;
    }
    renderProjectPaneSection(lines, selectedIndex, width, theme, rosterIndexByKey) {
        const entries = this.entries.filter((entry) => entry.surface === "project-pane");
        if (!entries.length)
            return;
        lines.push("", truncateToWidth(`  ${theme.fg("dim", "project panes")}`, width));
        for (const entry of entries) {
            const rosterIndex = rosterIndexByKey.get(entry.key) ?? 0;
            lines.push(this.renderEntry(rosterIndex, selectedIndex, entry, width, theme));
        }
    }
    renderEntry(rosterIndex, selectedIndex, entry, width, theme, branch, unclipped = false) {
        const label = entry.displayLabel ?? entry.agent;
        const agent = entry.modelThinking ? `${label} (${entry.modelThinking})` : label;
        const prefix = branch ? `    ${branch}` : " ";
        const checklist = entry.workflowWrapper && entry.workflowChecklist
            ? ` · checklist ${formatWorkflowChecklistSummary(entry.workflowChecklist)}${entry.workflowChecklist.bottleneck ? ` · bottleneck ${formatWorkflowChecklistBottleneck(entry.workflowChecklist.bottleneck)}` : ""}`
            : "";
        const left = `${prefix} ${this.bullet(rosterIndex, selectedIndex, theme)} ${theme.fg(fleetAgentIdentityColor(entry.agent), agent)} · ${entry.state}${checklist}`;
        const elapsed = Date.now() - entry.startedAt;
        const rightText = entry.projectPane
            ? `${entry.projectPane.summary ?? "—"} · ${formatFleetElapsed(Date.now() - entry.projectPane.refreshedAt)} ago`
            : entry.external ? formatFleetElapsed(elapsed) : `${formatFleetElapsed(elapsed)} · ${entry.workflowWrapper ? "usage on child rows" : formatFleetTokens(entry.tokens, entry.window)}`;
        const right = theme.fg("dim", rightText);
        if (unclipped)
            return `${left} ${right}`;
        return rightAlign(left, right, width);
    }
    renderNestedRow(row, last, width, theme) {
        const marker = last ? "└─" : "├─";
        const indent = "    ".repeat(row.depth + 1);
        if (row.overflow !== undefined)
            return truncateToWidth(`${indent}${marker} ${theme.fg("dim", `+${row.overflow} nested leaves`)}`, width);
        const modelThinking = row.modelThinking ? ` (${row.modelThinking})` : "";
        const activity = row.activity ? ` · ${row.activity}` : "";
        const left = `${indent}${marker} ${nestedStatusGlyph(row.state, theme, row.thinking)} ${theme.fg(fleetAgentIdentityColor(row.agentIdentity ?? row.name), `${row.name}${modelThinking}`)} · ${row.state}${activity}`;
        const elapsed = detailElapsed(row);
        return truncateToWidth(`${left}${elapsed !== undefined ? theme.fg("dim", ` · ${elapsed}`) : ""}`, width);
    }
    workflowRowGlyph(row, theme) {
        if (!row.kind)
            return nestedStatusGlyph(row.state, theme, row.thinking);
        const state = row.state;
        if (state === "pending")
            return theme.fg("muted", "◦");
        if (state === "running")
            return theme.fg("accent", "●");
        if (state === "done")
            return row.verdict === "pass" ? theme.fg("success", "✓") : row.verdict === "fail" ? theme.fg("error", "✗") : theme.fg("warning", "■");
        if (state === "error")
            return theme.fg("error", "✗");
        return theme.fg("warning", "■");
    }
    workflowRowStateLabel(row, theme) {
        const state = row.kind ? hostStepVerdictLabel(row.state, row.verdict) : row.state;
        if (state === "running")
            return row.kind ? theme.fg("accent", state) : runningTone(theme, row.thinking)(state);
        if (state === "pending" || state === "queued")
            return theme.fg("muted", state);
        if (state === "pass" || state === "complete" || state === "completed")
            return theme.fg("success", state === "pass" ? "pass" : "complete");
        if (state === "fail" || state === "failed" || state === "error")
            return theme.fg("error", state === "fail" ? "fail" : state);
        return theme.fg("warning", state);
    }
    renderWorkflowPhaseRow(phase, last, width, theme) {
        const marker = last ? "└─" : "├─";
        const glyph = phase.state === "complete"
            ? theme.fg("success", "✓")
            : phase.state === "running"
                ? runningTone(theme)("●")
                : phase.state === "blocked" || phase.state === "failed"
                    ? theme.fg("error", phase.state === "blocked" ? "!" : "✗")
                    : phase.state === "queued"
                        ? theme.fg("muted", "◦")
                        : theme.fg("warning", "■");
        return truncateToWidth(`    ${marker} ${glyph} ${theme.fg("muted", formatWorkflowChecklistPhase(phase))}`, width);
    }
    renderWorkflowRow(row, last, width, theme) {
        const marker = last ? "└─" : "├─";
        const indent = "    ";
        if (row.overflow !== undefined)
            return truncateToWidth(`${indent}${marker} ${theme.fg("dim", `+${row.overflow} hidden workflow steps`)}`, width);
        const context = contextModeLabel(row.context);
        const modelThinking = row.modelThinking ? ` (${row.modelThinking})` : "";
        const activity = row.activity ? ` · ${row.activity}` : "";
        const kind = row.kind ? `${row.kind}: ` : "";
        const hints = row.preflight ? [
            row.preflight.mode ? `mode:${row.preflight.mode}` : undefined,
            row.preflight.decision ? `decision:${row.preflight.decision}` : undefined,
            row.preflight.claims?.length ? `claims:${row.preflight.claims.join(",")}` : undefined,
            row.preflight.expectedOutput ? `expected:${row.preflight.expectedOutput}` : undefined,
            row.preflight.independence ? `independence:${row.preflight.independence}` : undefined,
        ].filter((value) => Boolean(value)).join(" · ") : "";
        const left = `${indent}${marker} ${this.workflowRowGlyph(row, theme)} ${theme.fg("muted", `${kind}${row.name}${context ? ` ${context}` : ""}${modelThinking}`)} · ${this.workflowRowStateLabel(row, theme)}${activity}${hints ? ` · ${hints}` : ""}`;
        const details = [
            detailElapsed(row),
            row.tokens !== undefined ? formatFleetTokens(row.tokens, row.window) : undefined,
            row.provider ? `provider:${row.provider}` : undefined,
            row.role ? `role:${row.role}` : undefined,
            row.target,
            row.detail,
            row.reasonCode ? `reason:${row.reasonCode}` : undefined,
            row.freshness?.stale ? "stale" : row.freshness?.observedRef ? `ref:${row.freshness.observedRef}` : undefined,
            row.reportPath ? `out:${hostStepReportName(row.reportPath)}` : undefined,
        ].filter(Boolean).join(" · ");
        return truncateToWidth(`${left}${details ? theme.fg("dim", ` · ${details}`) : ""}`, width);
    }
    bullet(rosterIndex, selectedIndex, theme) {
        return rosterIndex === selectedIndex ? theme.fg("accent", ">") : " ";
    }
    rosterKeys() {
        return ["main", ...this.entries.map((entry) => entry.key)];
    }
    clampSelection() {
        if (!this.rosterKeys().includes(this.selectedKey))
            this.selectedKey = "main";
    }
    deactivate() {
        this.active = false;
        this.selectedKey = "main";
        this.refresh();
    }
    editorHasFocus() {
        // pi-tui exposes focus mutation but no focus getter, so inspect the focused
        // component structurally. instanceof is unreliable across jiti module boundaries.
        const focused = this.tui?.focusedComponent;
        if (!focused || typeof focused !== "object")
            return false;
        const candidate = focused;
        return typeof candidate.render === "function"
            && typeof candidate.invalidate === "function"
            && typeof candidate.handleInput === "function"
            && typeof candidate.getText === "function"
            && typeof candidate.setText === "function";
    }
    getRenderKey() {
        const now = Date.now();
        return JSON.stringify({
            active: this.active,
            selected: this.selectedKey,
            inspectorOpen: this.inspectorOpen,
            entries: this.entries.map((entry) => this.active
                ? [
                    entry.key,
                    entry.surface,
                    entry.parentKey,
                    entry.agent,
                    entry.displayLabel,
                    entry.state,
                    entry.modelThinking,
                    entry.description,
                    entry.external,
                    Math.round((now - entry.startedAt) / 1000),
                    entry.tokens,
                    entry.workflowChecklist ? [
                        entry.workflowChecklist.total,
                        entry.workflowChecklist.done,
                        entry.workflowChecklist.running,
                        entry.workflowChecklist.queued,
                        entry.workflowChecklist.blocked,
                        entry.workflowChecklist.failed,
                        entry.workflowChecklist.phases.map((phase) => [phase.key, phase.state, phase.done, phase.total, phase.running, phase.queued, phase.blocked, phase.failed, phase.items.map((item) => [item.key, item.state, item.currentTool, item.currentPath, item.durationMs, item.toolCount, item.error])]),
                    ] : undefined,
                    visibleWorkflowRows(entry.workflowRows, entry.parentKey ? 2 : 4).map((row) => [
                        row.kind,
                        row.name,
                        row.state,
                        row.context,
                        row.modelThinking,
                        row.activity,
                        row.startedAt,
                        row.endedAt,
                        row.durationMs,
                        row.tokens,
                        row.provider,
                        row.role,
                        row.verdict,
                        row.reasonCode,
                        row.detail,
                        row.target,
                        row.freshness,
                        row.reportPath,
                        row.overflow,
                    ]),
                    nestedFleetRows(entry.nestedChildren, entry.parentKey ? 3 : 4).map((row) => [
                        row.name,
                        row.agentIdentity,
                        row.state,
                        row.modelThinking,
                        row.activity,
                        row.startedAt,
                        row.endedAt,
                        row.depth,
                        row.overflow,
                    ]),
                ]
                : [entry.key, entry.state, entry.external, entry.surface, entry.tokens, entry.projectPane?.refreshedAt, entry.projectPane?.summary]),
        });
    }
    hasInlineSurface() {
        return this.entries.length > 0 || Boolean(this.state.activeAsyncCapacity?.used);
    }
    getActiveUiContext() {
        const ctx = this.ctx;
        if (!ctx)
            return undefined;
        try {
            return ctx.hasUI ? ctx : undefined;
        }
        catch (error) {
            if (!isStaleExtensionContextError(error))
                throw error;
            this.clearUiRegistration();
            return undefined;
        }
    }
    clearWidget() {
        this.prepaint = undefined;
        this.clearWorkflowCoverage();
        if (!this.widgetRegistered)
            return;
        try {
            this.ui?.setWidget(FLEET_STATUS_WIDGET_KEY, undefined);
        }
        catch (error) {
            if (!isStaleExtensionContextError(error))
                throw error;
            this.clearUiRegistration();
            return;
        }
        this.widgetRegistered = false;
        this.tui = undefined;
    }
    clearUiRegistration() {
        this.prepaint = undefined;
        this.clearWorkflowCoverage();
        if (this.timer)
            clearInterval(this.timer);
        this.timer = undefined;
        const inputUnsubscribe = this.inputUnsubscribe;
        const ui = this.ui;
        const widgetRegistered = this.widgetRegistered;
        this.inputUnsubscribe = undefined;
        this.ctx = undefined;
        this.ui = undefined;
        this.widgetRegistered = false;
        this.tui = undefined;
        const cleanupErrors = [];
        try {
            inputUnsubscribe?.();
        }
        catch (error) {
            if (!isStaleExtensionContextError(error))
                cleanupErrors.push(error);
        }
        if (ui && widgetRegistered) {
            try {
                ui.setWidget(FLEET_STATUS_WIDGET_KEY, undefined);
            }
            catch (error) {
                if (!isStaleExtensionContextError(error))
                    cleanupErrors.push(error);
            }
        }
        if (cleanupErrors.length === 1)
            throw cleanupErrors[0];
        if (cleanupErrors.length > 1) {
            throw new AggregateError(cleanupErrors, "Failed to clean up FleetView UI registration");
        }
    }
    clearWorkflowCoverage() {
        if (this.ui)
            this.onWorkflowCoverageChange?.(this.ui, new Map());
    }
}
//# sourceMappingURL=fleet-status.js.map