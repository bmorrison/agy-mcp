/**
 * Type definitions for the subagent extension
 */
import * as os from "node:os";
import * as path from "node:path";
export const SUBAGENT_LIFECYCLE_ARTIFACT_VERSION = 3;
export const INTERCOM_DETACH_REQUEST_EVENT = "pi-intercom:detach-request";
export const INTERCOM_DETACH_RESPONSE_EVENT = "pi-intercom:detach-response";
/** pi-intercom asks each session for a fixed intercom ID at session start; `claim(id)` answers synchronously. */
export const INTERCOM_SESSION_IDENTITY_EVENT = "intercom:session-identity";
export const SUBAGENT_ASYNC_STARTED_EVENT = "subagent:async-started";
/** Launcher names are plain identifiers so they survive frontmatter rewrites without quoting. */
export const RUNNER_LAUNCHER_NAME_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/u;
export const RUNNER_LAUNCHER_NAME_RULE = "must start with a letter or digit and use only letters, digits, '.', '_' or '-' (at most 128 characters)";
export const SUBAGENT_ASYNC_COMPLETE_EVENT = "subagent:async-complete";
export const SUBAGENT_PROCESS_TERMINAL_EVENT = "subagent:process-terminal";
export const SUBAGENT_FOREGROUND_COMPLETE_EVENT = "subagent:foreground-complete";
export const SUBAGENT_CONTROL_EVENT = "subagent:control-event";
export const SUBAGENT_CONTROL_INTERCOM_EVENT = "subagent:control-intercom";
export const SUBAGENT_STEERING_NOTICE_EVENT = "subagent:steering-notice";
export const SUBAGENT_CHILD_STATUS_EVENT = "subagent:child-status";
export const SUBAGENT_RESULT_INTERCOM_EVENT = "subagent:result-intercom";
export const SUBAGENT_RESULT_INTERCOM_DELIVERY_EVENT = "subagent:result-intercom-delivery";
export const FLEET_KEYBINDING_ACTIONS = [
    "close",
    "scrollUp",
    "scrollDown",
    "selectUp",
    "selectDown",
    "selectFirst",
    "selectLast",
    "pageUp",
    "pageDown",
    "refresh",
    "steer",
    "inspect",
    "stop",
    "toggleTools",
];
// ============================================================================
// Constants
// ============================================================================
export const DEFAULT_MAX_OUTPUT = {
    bytes: 200 * 1024,
    lines: 5000,
};
export const DEFAULT_ARTIFACT_CONFIG = {
    enabled: true,
    dir: "session",
    includeInput: true,
    includeOutput: true,
    includeJsonl: false,
    includeTranscript: true,
    includeMetadata: true,
    cleanupDays: 7,
};
function sanitizeTempScopeSegment(value) {
    const sanitized = value
        .trim()
        .replace(/[^A-Za-z0-9._-]+/g, "-")
        .replace(/^-+|-+$/g, "");
    return sanitized || "unknown";
}
export function resolveTempScopeId(options) {
    const env = options?.env ?? process.env;
    const getuid = options && Object.hasOwn(options, "getuid")
        ? options.getuid
        : process.getuid?.bind(process);
    if (typeof getuid === "function") {
        return `uid-${getuid()}`;
    }
    for (const key of ["USERNAME", "USER", "LOGNAME"]) {
        const value = env[key];
        if (value)
            return `user-${sanitizeTempScopeSegment(value)}`;
    }
    const userInfo = options && Object.hasOwn(options, "userInfo")
        ? options.userInfo
        : os.userInfo;
    try {
        const username = userInfo?.().username;
        if (username)
            return `user-${sanitizeTempScopeSegment(username)}`;
    }
    catch {
        // Fall through to home-directory-based scoping.
    }
    const homedir = env.USERPROFILE ?? env.HOME;
    if (homedir)
        return `home-${sanitizeTempScopeSegment(homedir)}`;
    const resolveHomedir = options && Object.hasOwn(options, "homedir")
        ? options.homedir
        : os.homedir;
    try {
        const fallbackHomedir = resolveHomedir?.();
        if (fallbackHomedir)
            return `home-${sanitizeTempScopeSegment(fallbackHomedir)}`;
    }
    catch {
        // Fall through to the last-resort shared scope.
    }
    return "shared";
}
const MAX_PARALLEL = 8;
const MAX_CONCURRENCY = 4;
const configuredTempRoot = process.env.PI_SUBAGENTS_TEMP_ROOT?.trim();
export const TEMP_ROOT_DIR = configuredTempRoot
    ? path.resolve(configuredTempRoot)
    : path.join(os.tmpdir(), `pi-subagents-${resolveTempScopeId()}`);
export const RESULTS_DIR = path.join(TEMP_ROOT_DIR, "async-subagent-results");
export const ASYNC_DIR = path.join(TEMP_ROOT_DIR, "async-subagent-runs");
export const CHAIN_RUNS_DIR = path.join(TEMP_ROOT_DIR, "chain-runs");
export const TEMP_ARTIFACTS_DIR = path.join(TEMP_ROOT_DIR, "artifacts");
export const DIRS = {
    results: RESULTS_DIR,
    async: ASYNC_DIR,
    chain: CHAIN_RUNS_DIR,
    artifacts: TEMP_ARTIFACTS_DIR,
};
export const WIDGET_KEY = "subagent-async";
export const SLASH_RESULT_TYPE = "subagent-slash-result";
export const SLASH_TEXT_RESULT_TYPE = "subagent-slash-text-result";
export const SLASH_SUBAGENT_REQUEST_EVENT = "subagent:slash:request";
export const SLASH_SUBAGENT_STARTED_EVENT = "subagent:slash:started";
export const SLASH_SUBAGENT_RESPONSE_EVENT = "subagent:slash:response";
export const SLASH_SUBAGENT_UPDATE_EVENT = "subagent:slash:update";
export const SLASH_SUBAGENT_CANCEL_EVENT = "subagent:slash:cancel";
export const POLL_INTERVAL_MS = 250;
export const WIDGET_ANIMATION_INTERVAL_MS = 1000;
export const MAX_WIDGET_JOBS = 4;
export const DEFAULT_SUBAGENT_MAX_DEPTH = 2;
export const SUBAGENT_ACTIONS = ["list", "get", "models", "children.list", "guide", "validate", "create", "update", "delete", "eject", "disable", "enable", "reset", "mission.create", "mission.list", "mission.show", "mission.update", "mission.resolve-decision", "mission.attach-run", "mission.close", "worktree.discard", "worktree.cleanup", "lane.status", "lane.recordMerge", "lane.recordSupersession", "refine", "refine.show", "refine.rollback", "inspector.open", "inspector.command", "inspector.status", "inspector.close", "project.open", "project.status", "project.close", "status", "debug.run", "grant-spawn-budget", "interrupt", "resume", "steer", "stop", "command.status", "command.yield", "command.cancel", "dismiss", "doctor", "watchdog.status", "watchdog.check", "watchdog.configure", "watchdog.recommend-model", "schedule.create", "schedule.list", "schedule.show", "schedule.history", "schedule.pause", "schedule.resume", "schedule.run", "schedule.run-due", "schedule.delete"];
export const DEFAULT_FORK_PREAMBLE = "You are a delegated subagent running from a fork of the parent session. " +
    "Treat the inherited conversation as reference-only context, not a live thread to continue. " +
    "Do not continue or answer prior messages as if they are waiting for a reply. " +
    "Your sole job is to execute the task below and return a focused result for that task using your tools.";
function normalizeTopLevelParallelValue(value) {
    const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
    if (!Number.isInteger(parsed) || parsed < 1)
        return undefined;
    return parsed;
}
export function resolveTopLevelParallelMaxTasks(value) {
    return normalizeTopLevelParallelValue(value) ?? MAX_PARALLEL;
}
export function resolveTopLevelParallelConcurrency(override, configValue) {
    return normalizeTopLevelParallelValue(override)
        ?? normalizeTopLevelParallelValue(configValue)
        ?? MAX_CONCURRENCY;
}
export function getAsyncConfigPath(suffix) {
    return path.join(TEMP_ROOT_DIR, `async-cfg-${suffix}.json`);
}
export function wrapForkTask(task, preamble) {
    if (preamble === false)
        return task;
    const effectivePreamble = preamble ?? DEFAULT_FORK_PREAMBLE;
    const wrappedPrefix = `${effectivePreamble}\n\nTask:\n`;
    if (task.startsWith(wrappedPrefix))
        return task;
    return `${wrappedPrefix}${task}`;
}
// ============================================================================
// Recursion Depth Guard
// ============================================================================
function normalizeNonNegativeInteger(value) {
    const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
    if (!Number.isInteger(parsed) || parsed < 0)
        return undefined;
    return parsed;
}
export function normalizeMaxSubagentDepth(value) {
    return normalizeNonNegativeInteger(value);
}
/** Operator override for the top-level parent; children inherit their limit through their runtime config. */
const SUBAGENT_MAX_DEPTH_ENV = "PI_SUBAGENT_MAX_DEPTH";
export function resolveCurrentMaxSubagentDepth(configMaxDepth, runtime) {
    return normalizeMaxSubagentDepth(runtime ? runtime.maxDepth : process.env[SUBAGENT_MAX_DEPTH_ENV])
        ?? normalizeMaxSubagentDepth(configMaxDepth)
        ?? DEFAULT_SUBAGENT_MAX_DEPTH;
}
export function resolveChildMaxSubagentDepth(parentMaxDepth, agentMaxDepth) {
    const normalizedParent = normalizeMaxSubagentDepth(parentMaxDepth) ?? DEFAULT_SUBAGENT_MAX_DEPTH;
    const normalizedAgent = normalizeMaxSubagentDepth(agentMaxDepth);
    return normalizedAgent === undefined ? normalizedParent : Math.min(normalizedParent, normalizedAgent);
}
/** Depth of the executor itself: 0 for a top-level parent, its own child depth otherwise. */
function resolveCurrentSubagentDepth(runtime) {
    const depth = runtime ? runtime.depth : 0;
    return Number.isFinite(depth) ? depth : 0;
}
export function checkSubagentDepth(configMaxDepth, runtime) {
    const depth = resolveCurrentSubagentDepth(runtime);
    const maxDepth = resolveCurrentMaxSubagentDepth(configMaxDepth, runtime);
    const blocked = depth >= maxDepth;
    return { blocked, depth, maxDepth };
}
/** Depth context handed to a child launched by an executor at `runtime` (undefined for a top-level parent). */
export function resolveChildDepth(maxDepth, runtime) {
    return {
        depth: resolveCurrentSubagentDepth(runtime) + 1,
        maxDepth: normalizeMaxSubagentDepth(maxDepth) ?? resolveCurrentMaxSubagentDepth(undefined, runtime),
    };
}
export function normalizeMaxSubagentSpawnsPerSession(value) {
    return normalizeNonNegativeInteger(value);
}
export function resolveMaxSubagentSpawnsPerSession(configMaxSpawns) {
    const envMaxSpawns = normalizeMaxSubagentSpawnsPerSession(process.env.PI_SUBAGENT_MAX_SPAWNS_PER_SESSION);
    if (envMaxSpawns !== undefined)
        return envMaxSpawns === 0 ? undefined : envMaxSpawns;
    const configuredMaxSpawns = normalizeMaxSubagentSpawnsPerSession(configMaxSpawns);
    return configuredMaxSpawns === 0 ? undefined : configuredMaxSpawns;
}
const DEFAULT_MAX_SUBAGENT_SPAWNS_PER_RUN = 64;
export function normalizeMaxSubagentSpawnsPerRun(value) {
    const normalized = normalizeNonNegativeInteger(value);
    return normalized !== undefined && normalized > 0 ? normalized : undefined;
}
export function resolveMaxSubagentSpawnsPerRun(configMaxSpawns) {
    return normalizeMaxSubagentSpawnsPerRun(process.env.PI_SUBAGENT_MAX_SPAWNS_PER_RUN)
        ?? normalizeMaxSubagentSpawnsPerRun(configMaxSpawns)
        ?? DEFAULT_MAX_SUBAGENT_SPAWNS_PER_RUN;
}
// ============================================================================
// Utility Functions
// ============================================================================
function formatBytes(bytes) {
    if (bytes < 1024)
        return `${bytes}B`;
    if (bytes < 1024 * 1024)
        return `${(bytes / 1024).toFixed(1)}KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)}MB`;
}
export function truncateOutput(output, config, artifactPath) {
    const lines = output.split("\n");
    const bytes = Buffer.byteLength(output, "utf-8");
    if (bytes <= config.bytes && lines.length <= config.lines) {
        return { text: output, truncated: false };
    }
    let truncatedLines = lines;
    if (lines.length > config.lines) {
        truncatedLines = lines.slice(0, config.lines);
    }
    let result = truncatedLines.join("\n");
    if (Buffer.byteLength(result, "utf-8") > config.bytes) {
        let low = 0;
        let high = result.length;
        while (low < high) {
            const mid = Math.floor((low + high + 1) / 2);
            if (Buffer.byteLength(result.slice(0, mid), "utf-8") <= config.bytes) {
                low = mid;
            }
            else {
                high = mid - 1;
            }
        }
        result = result.slice(0, low);
    }
    const keptLines = result.split("\n").length;
    const marker = `[TRUNCATED: showing first ${keptLines} of ${lines.length} lines, ${formatBytes(Buffer.byteLength(result))} of ${formatBytes(bytes)}${artifactPath ? ` - full output at ${artifactPath}` : ""}]\n`;
    return {
        text: marker + result,
        truncated: true,
        originalBytes: bytes,
        originalLines: lines.length,
        artifactPath,
    };
}
//# sourceMappingURL=types.js.map