import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import type { ControlEvent, SubagentState } from "../shared/types.ts";
export declare const SUBAGENT_CONTROL_MESSAGE_TYPE = "subagent_control_notice";
export interface SubagentControlMessageDetails {
    event: ControlEvent;
    source?: "foreground" | "async" | "goal";
    asyncDir?: string;
    childIntercomTarget?: string;
    noticeText?: string;
    /** Status-only copy of a supervisor request; the tracker sends the notice later if the request is still unanswered. */
    noticeDeferred?: boolean;
}
export declare function handleSubagentControlNotice(input: {
    pi: Pick<ExtensionAPI, "sendMessage">;
    state: SubagentState;
    visibleControlNotices: Set<string>;
    details: SubagentControlMessageDetails;
}): void;
//# sourceMappingURL=control-notices.d.ts.map